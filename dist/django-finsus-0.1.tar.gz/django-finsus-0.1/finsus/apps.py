from django.apps import AppConfig


class FinsusConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'finsus'
